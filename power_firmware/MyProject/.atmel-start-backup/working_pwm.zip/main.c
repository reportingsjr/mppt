#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	pwm_set_parameters(&PWM_0, 160, 150);
	pwm_enable(&PWM_0);

	// enable the FET driver
	gpio_set_pin_level(fet_enable, true);

	delay_init(SysTick);

	/* Replace with your application code */
	while (1) {
		gpio_set_pin_level(yellow_led, true);
		gpio_set_pin_level(green_led, true);
		//pwm_set_parameters(&PWM_0, 160, 20);
		delay_ms(1000);
		gpio_set_pin_level(yellow_led, false);
		gpio_set_pin_level(green_led, false);
		//pwm_set_parameters(&PWM_0, 160, 150);
		delay_ms(1000);
	}
}
