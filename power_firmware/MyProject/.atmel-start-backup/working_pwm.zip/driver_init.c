/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_init.h"
#include <peripheral_clk_config.h>
#include <utils.h>
#include <hal_init.h>
#include <hpl_gclk_base.h>
#include <hpl_pm_base.h>

struct pwm_descriptor PWM_0;

void PWM_0_PORT_init(void)
{

	gpio_set_pin_function(fet_pwm, PINMUX_PA10E_TCC1_WO0);
}

void PWM_0_CLOCK_init(void)
{
	_pm_enable_bus_clock(PM_BUS_APBC, TCC1);
	_gclk_enable_channel(TCC1_GCLK_ID, CONF_GCLK_TCC1_SRC);
}

void PWM_0_init(void)
{
	PWM_0_CLOCK_init();
	PWM_0_PORT_init();
	pwm_init(&PWM_0, TCC1, _tcc_get_pwm());
}

void system_init(void)
{
	init_mcu();

	// GPIO on PA00

	gpio_set_pin_level(yellow_led,
	                   // <y> Initial level
	                   // <id> pad_initial_level
	                   // <false"> Low
	                   // <true"> High
	                   false);

	// Set pin direction to output
	gpio_set_pin_direction(yellow_led, GPIO_DIRECTION_OUT);

	gpio_set_pin_function(yellow_led, GPIO_PIN_FUNCTION_OFF);

	// GPIO on PA01

	gpio_set_pin_level(green_led,
	                   // <y> Initial level
	                   // <id> pad_initial_level
	                   // <false"> Low
	                   // <true"> High
	                   false);

	// Set pin direction to output
	gpio_set_pin_direction(green_led, GPIO_DIRECTION_OUT);

	gpio_set_pin_function(green_led, GPIO_PIN_FUNCTION_OFF);

	// GPIO on PA11

	gpio_set_pin_level(fet_enable,
	                   // <y> Initial level
	                   // <id> pad_initial_level
	                   // <false"> Low
	                   // <true"> High
	                   false);

	// Set pin direction to output
	gpio_set_pin_direction(fet_enable, GPIO_DIRECTION_OUT);

	gpio_set_pin_function(fet_enable, GPIO_PIN_FUNCTION_OFF);

	PWM_0_init();
}
